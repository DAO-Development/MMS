<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package MMS
 */

get_header();
?>

	<main id="primary" class="site-main">

		<section class="promo">
			<div class="container">
				<h1 class="promo-title"><?php bloginfo('name'); ?></h1>
				<p class="description"><?php bloginfo('description'); ?></p>
				<a class="btn" href="ссылка_на_запись">Записаться на сеанс</a>
			</div>
		</section>

		<section class="information">
				<div>
					<img class="inf-icon" src="wp-content/themes/mms/assets/images/geo.png">
					<div class="inf-text">
						<p>Адрес</p>
						<p>Москва ул. Миклухо-Маклая, 18/1</p>
					</div>
					
				</div>
				<div>
					<img class="inf-icon" src="wp-content/themes/mms/assets/images/time.png">
					<div class="inf-text">
						<p>Время работы</p>
						<p>пн.-вс.: 10:00-22:00</p>		
					</div>			
				</div>
				<div>
					<img class="inf-icon" src="wp-content/themes/mms/assets/images/phone.png">
						
					<img class="phone-icon" src="wp-content/themes/mms/assets/images/whatsapp-white.png">
					<img class="phone-icon" src="wp-content/themes/mms/assets/images/telegram-white.png">		

					<div class="inf-text">
						<p>Наш телефон</p>
						<p>+7 (926) 729 49 42</p>
					</div>
				</div>
		</section>

		<section class="promotions-block">
			<div class="container">
				<h2>Акции</h2>
				<div class="promotions">
					<?php // параметры по умолчанию
					$posts = get_posts( array(
						'numberposts' => 3,
						'category'    => 0,
						'orderby'     => 'date',
						'order'       => 'ASC',
						'include'     => array(),
						'exclude'     => array(),
						'meta_key'    => '',
						'meta_value'  =>'',
						'post_type'   => 'promotions',
						'suppress_filters' => true, // подавление работы фильтров изменения SQL запроса
					) );

					foreach( $posts as $post ){
						setup_postdata($post);?>
							<div class="single-promotion">
								<?php the_post_thumbnail('promotions'); ?>
								<?php if (strcmp(get_the_title(), "Подарочный сертификат") == 0) : ?>
									<a class="promo-btn" href="#">Узнать подробнее</a>
								<?php endif; ?>
							</div>
					    <?php
					} ?>
				</div>
			</div>

			
		</section>

		<section class="services-block">
			<div class="container">
				<h2>Наши услуги</h2>
				<div class="services">
					<?php // параметры по умолчанию
					$posts = get_posts( array(
						'numberposts' => 0,
						'category'    => 0,
						'orderby'     => 'date',
						'order'       => 'ASC',
						'include'     => array(),
						'exclude'     => array(),
						'meta_key'    => '',
						'meta_value'  =>'',
						'post_type'   => 'services',
						'suppress_filters' => true, // подавление работы фильтров изменения SQL запроса
					) );

					foreach( $posts as $post ){
						setup_postdata($post);?>
							<div class="single-service">
								<?php the_post_thumbnail('services'); ?>
								<h5><?php the_title(); ?></h5>
								<?php the_content();?>

								<div class="cost-table">
									<?php if (get_field('max_cost') != null) : ?>
										<p class="title title-cost">Стоимость</p>
										<?php if (get_field('min_cost') != null) : ?>
											<p class="cost value"><?php the_field('min_cost')?>-<?php the_field('max_cost')?>₽</p>
										<?php else: ?>
											<p class="cost value"><?php the_field('max_cost')?>₽</p>
										<?php endif;?>
									<?php endif; ?>

									<?php if (get_field('max_duration') != null) : ?>
										<p class="title title-duration">Длительность</p>
										<?php if (get_field('min_duration') != null) : ?>
											<p class="duration value"><?php the_field('min_duration')?>-<?php the_field('max_duration')?> минут</p>
										<?php else: ?>
											<p class="duration value"><?php the_field('max_duration')?> минут</p>
										<?php endif;?>
									<?php endif; ?>

									<?php if (get_field('cost_1_area') != null) : ?>
										<p class="title title-cost-1-area">Стоимость 1 зоны</p>
											<p class="cost-1-area value"><?php the_field('cost_1_area')?>₽</p>
									<?php endif; ?>

									<?php if (get_field('cost_2_area') != null) : ?>
										<p class="title title-cost-2-area">Стоимость 2 зон</p>
											<p class="cost-2-area value"><?php the_field('cost_2_area')?>₽</p>
									<?php endif; ?>

									<?php if (get_field('cost_3_area') != null) : ?>
										<p class="title title-cost-3-area">Стоимость 3 зон</p>
											<p class="cost-3-area value"><?php the_field('cost_3_area')?>₽</p>
									<?php endif; ?>
								</div>

								<a class="btn" href="ссылка_на_запись">Записаться</a>
							</div>
					    <?php
					} ?>
				</div>
			</div>			
		</section>

	</main><!-- #main -->

<?php
get_footer();
